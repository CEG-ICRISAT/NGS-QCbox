#!/bin/bash
echo $(awk -c fastx '{sum += length($seq)}END{print sum}' $1)
